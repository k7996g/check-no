package com.capgemini.teakehome.exception;
// Exception class for Invalid product code
public class InvalidProductCodeException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidProductCodeException(String s) {
		super(s);

	}
}
