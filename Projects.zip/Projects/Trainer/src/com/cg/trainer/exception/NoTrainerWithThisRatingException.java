package com.cg.trainer.exception;
//
public class NoTrainerWithThisRatingException extends Exception{

}