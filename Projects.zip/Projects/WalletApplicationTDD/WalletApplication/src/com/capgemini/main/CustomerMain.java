package com.capgemini.main;

import java.math.BigDecimal;

import com.capgemini.exceptions.DuplicateMobileNumberException;
import com.capgemini.exceptions.InsufficientAmountException;
import com.capgemini.exceptions.InvalidMobileNumberException;
import com.capgemini.repo.WalletRepoImpl;
import com.capgemini.service.WalletServiceImpl;

public class CustomerMain {
	public static void main(String[] args) throws Exception {

		WalletRepoImpl walletRepo = new WalletRepoImpl();

		WalletServiceImpl walletService = new WalletServiceImpl(walletRepo);

		try {
			System.out.println(walletService.createAccount("sushil", "9854121412", new BigDecimal("100.00")));
			System.out.println(walletService.createAccount("suraj", "9854121413", new BigDecimal("500.00")));
			System.out.println(walletService.depositAmount("9854121413", new BigDecimal("500.00")));
			System.out.println(walletService.withdrawAmount("9854121413", new BigDecimal("100.00")));
			System.out.println(walletService.showBalance("9854121413").getWallet());
			System.out.println(walletService.fundTransfer("9854121413", "9854121412", new BigDecimal("200.00")));

		} catch (DuplicateMobileNumberException duplicateMobileException) {
			System.out.println("Duplicate Mobile Number Found : " + duplicateMobileException);
		} catch (InsufficientAmountException insufficientAmountException) {
			System.out.println("Insufficient Amount in Wallet : " + insufficientAmountException);
		} catch (InvalidMobileNumberException invalidMobileException) {
			System.out.println("Mobile Number Doesn't Exist : " + invalidMobileException);
		}

	}
}
