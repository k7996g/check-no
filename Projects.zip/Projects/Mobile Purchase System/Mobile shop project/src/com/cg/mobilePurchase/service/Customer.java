package com.cg.mobilePurchase.service;



public interface Customer {
	void addCustName(String name);

	void addCustMailId(String id);

	void addCustMobNo(String no);

	void addCustPurchaseDate();

	void addCustPurchaseId();

	void addCustMobId(String mobname);
}
