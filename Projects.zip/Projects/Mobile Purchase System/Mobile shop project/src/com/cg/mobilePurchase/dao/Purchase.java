package com.cg.mobilePurchase.dao;

public interface Purchase {
void showMobileByRange(int startingRange,int maxRange);
int purchase(String mobname);
}
