package com.cg.mobilePurchase.util;

public interface MobDetails {
void addMobileDetails();
void deleteMobById(int id);
void availableMobiles();
}
